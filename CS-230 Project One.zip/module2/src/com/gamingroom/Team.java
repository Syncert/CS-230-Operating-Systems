package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/*
 * A simple class to hold information about a team
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * @author nkreuziger@snhu.com
 * @date 7/10/2022
 * @version 1.0
 *
 */
public class Team extends Entity {
	
	//Array of Players on the team
	private List<Player> players = new ArrayList<Player>();

	//team constructor
	public Team (long id, String name) {
		this.id = id;
		this.name = name;
	}
	
	public Player addPlayer(String name) {
		// a local game instance
		Player player = null;

		// Use iterator to look for existing Player with same name
		// looping over Player names, return if match, create if not
		
		for (int i = 0; i < players.size(); ++i) {
			
			if (name == players.get(i).getName()) {
				//player exists, assign it to player
				player = players.get(i);
			}
			
		}
		
		// if not found, make a new Player instance and add to list of Players in Team
		if (player == null) {
			
			//increment player id
			int playerID = players.size();
			playerID++;
			
			player = new Player(playerID , name);
			players.add(player);
		}

		// return the new/existing game instance to the caller
		return player;	
	}
	

	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + "]";
	}
}


/*

	//CLASS to test player creation non-duplication
	public void printPlayers() {

		for (int i = 0; i < players.size(); ++i) {
			
			System.out.println(players.get(i));
			
		}
	}

*/