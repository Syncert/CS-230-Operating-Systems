package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A singleton service for the game engine.
 * The Singleton Pattern is a program allowing only one class object to be in existence at run-time while also 
 * being accessible. This functionality averts duplication of any object during runtime. In this instance the 
 * Singleton Pattern is used to ensure no duplicates of games nor player/team combinations in association with 
 * the single class.
 * 
 * @author nkreuziger@snhu.com
 * @date 7/10/2022
 * @version 1.0
 */
public class GameService {
	
	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;

	// FIXME: Add missing pieces to turn this class a singleton 
	
	private static GameService instance = new GameService();
	
	
	//Private constructor so class cannot be initiated, hallmark of singleton
	private GameService() {}
	
	//Get the only object available, allows for various design patterns to keep on referencing back
	//to the only allowed class.
	public static GameService getInstance() {
		return instance;
	}
	
	//
	
	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;

		// FIXME: Use iterator to look for existing game with same name
		// looping over game names, return if match, create if not
		
		for (int i = 0; i < games.size(); ++i) {
			
			if (name == games.get(i).getName()) {
				//game exists, get it
				GameService.getInstance();
			}
			
		}
		
		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		// FIXME: Use iterator to look for existing game with same id
		
		// if found, simply assign that instance to the local variable
		
		//iterating over the array of games to check if the game object id exists, if so reference instance
		for (int i = 0; i < games.size(); ++i) {
			
			if (id == games.get(i).getId()) {
				//assign
				GameService.getInstance();
			}
			
		}
		
		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		// FIXME: Use iterator to look for existing game with same name
		// if found, simply assign that instance to the local variable
		
		for (int i = 0; i < games.size(); ++i) {
			
			if (name == games.get(i).getName()) {
				//assign
				GameService.getInstance();
			}
			
		}
		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
}
