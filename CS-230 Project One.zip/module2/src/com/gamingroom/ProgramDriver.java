package com.gamingroom;

/**
 * Gaming Room Application. This program's intent is to host non-duplicate games that multiple users are allowed to
 * play at any given point. This program is designed with a Singleton Class. The Singleton Pattern is a program
 * allowing only one class object to be in existence at run-time. This functionality averts duplication of any object
 * during runtime. In this instance the Singleton Pattern is used to ensure no duplicates of games nor player/team 
 * combinations. 
 * 
 * GameService Class: Hosts Game Objects.
 * 
 * Entity Class: 
 * Class that is used to set the base for Game, Player and Team Classes. Defines name, id , accessors for name and id 
 * in addition to the toString() function to be overrode by the sub-classes.
 * 
 * Game Class:
 * Games cannot be allowed to duplicate. Nor be mutable. Iterators are used to check if a game exists at time of creation
 * or access.
 * 
 * Player/Team Class: 
 * Multiple instances of a game can be running at once, each having players and teams. Iterators are used to check if 
 * the name chosen is already in use with a game. Players/Teams cannot be allowed to duplicate, or be mutable.
 * 
 * @author nkreuziger@snhu.com
 * @date 7/10/2022
 * @version 1.0
 */
public class ProgramDriver {
	
	/**
	 * The one-and-only main() method
	 * 
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		
		// FIXME: obtain reference to the singleton instance
		//Reference the instance of Game Service class
		GameService service = GameService.getInstance();
		
		System.out.println("\nAbout to test initializing game data...");
		
		// initialize with some game data
		Game game1 = service.addGame("Game #1");
		System.out.println(game1);
		Game game2 = service.addGame("Game #2");
		System.out.println(game2);
		
		Team team1 = game1.addTeam("Team 1");
		team1.addPlayer("Joe");
		team1.addPlayer("Joe");
		team1.addPlayer("Bob");

		Team team2 = game1.addTeam("Team 2");
		team2.addPlayer("BillyBob");
		team2.addPlayer("Nicholas");
		team2.addPlayer("joel");
		
		game1.addTeam("Team 1");
			
		
		// use another class to prove there is only one instance
		SingletonTester tester = new SingletonTester();
		tester.testSingleton();
	}
}


/*
 * Below is code used for testing purposes
System.out.println("\nAbout to test team/name duplication...");			
game1.printTeams();
team1.printPlayers();
*/
