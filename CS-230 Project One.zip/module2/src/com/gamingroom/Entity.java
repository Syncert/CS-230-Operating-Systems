package com.gamingroom;

/*
 * The Entity class serves as a template for the Game, Team and Player classes to inherit id, name
 * and their associated mutators and accessors. In addition the ability to output a string description
 * is inherited.
 * 
 * @author nkreuziger@snhu.com
 * @date 7/17/2022
 * @version 1.0
 * 
 */


public class Entity {
	
	//id ane names to be inherited for game, team and player classes
	protected long id; 
	protected String name;
	
	//protect to avoid any initiation of an empty Entity
	protected Entity() {}
	
	public Entity (long id, String name) {
		this();
		this.id = id;
		this.name = name;
	}
	
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	public String toString() {
		return "[id= " + id + ", name=" + name + "]";	
	}
}
